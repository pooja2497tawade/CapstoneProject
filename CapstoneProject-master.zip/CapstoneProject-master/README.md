__References__

fakestore: https://fakestoreapi.com/docs

createProduct: https://www.baeldung.com/spring-resttemplate-post-json
